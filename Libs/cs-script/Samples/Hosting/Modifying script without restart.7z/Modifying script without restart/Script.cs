using System;

public class Script
{
    public static void Execute()
    {
        Console.WriteLine("Hello world!"); 
    }
}

