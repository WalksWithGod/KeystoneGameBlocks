LIMITED WARRANTY/LIMITATION OF LIABILITY:

This Software is provided "AS IS". If for any reason you are dissatisfied with the Software,
remove it from your computer system and destroy all copies of it. These warranties are in lieu
of any other warranties, expressed or implied, including the implied warranties of merchantability
and fitness for a particular purpose. In no event will IONSTAR Studios be liable to you for damages,
including any loss of profits, lost savings, or other incidental or consequential damages arising
out of your use of or inability to use the Software, even if IONSTAR Studios has been advised of the
possibility of such damages.

INDEMNIFICATION:

By installing and using the Software, you hereby agree to save and hold harmless IONSTAR Studios from any
loss, direct or consequential damage, or claim incurred by you resulting from reliance upon the
results obtained through the use of the Software.


LICENSE INFORMATION: 

The SQUID SDK source code is copyright protected by IONSTAR Studios, all rights reserved.
Decompilation and/or disassembly of the library is strictly forbidden.
The software is provided strictly for non-commercial use only and must not be distributed as part of a commercial product.

Please refer to our customer service at info@IONSTAR.org for licensing information.