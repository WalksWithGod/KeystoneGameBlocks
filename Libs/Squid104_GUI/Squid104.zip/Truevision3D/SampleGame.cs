﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Squid;
using Framework;

namespace SquidTV3D
{
    public class SampleGame : Game
    {
        protected override void Initialize()
        {
            //Engine.SetVSync(true);
            //Engine.DisplayFPS(true);
            Engine.AddSearchDirectory(AppDomain.CurrentDomain.BaseDirectory + "Content\\");
            Engine.AddSearchDirectory(AppDomain.CurrentDomain.BaseDirectory + "Content\\Cursors\\");
          
            GuiHost.Renderer = new RendererTV3D();
            GuiHost.GlobalFadeSpeed = 250;

            InputManager input = new InputManager(this);
            Components.Add(input);

            SampleScene scene = new SampleScene(this);
            Components.Add(scene);
            
            base.Initialize();
        }
    }
}
