﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Framework;
using Squid;
using MTV3D65;

namespace SquidTV3D
{
    public class InputManager : GameComponent
    {
        private int LastScroll;
        private TV_KEYDATA[] KeyBuffer;

        public InputManager(Game game)
            : base(game)
        {
            KeyBuffer = new TV_KEYDATA[0x100];
        }

        public override void Update(GameTime time)
        {
            bool[] buttons = new bool[4];
            int mx = 0; int my = 0; int scroll = 0; int num = 0; 
            
            Game.Input.GetAbsMouseState(ref mx, ref my, ref buttons[0], ref buttons[1], ref buttons[2], ref buttons[3], ref scroll);

            int wheel = scroll > LastScroll ? -1 : (scroll < LastScroll ? 1 : 0);
            LastScroll = scroll;

            Game.Input.GetKeyBuffer(KeyBuffer, ref num);

            GuiHost.SetMouse(mx, my, wheel);
            GuiHost.SetButtons(buttons);

            KeyData[] keys = new KeyData[num];
            for (int i = 0; i < keys.Length; i++)
            {
                keys[i].Scancode = KeyBuffer[i].Key;
                keys[i].Pressed = KeyBuffer[i].Pressed != 0;
                keys[i].Released = KeyBuffer[i].Released != 0;
            }

            GuiHost.SetKeyboard(keys);
            GuiHost.TimeElapsed = time.ElapsedMilliseconds;

            base.Update(time);
        }
    }
}
