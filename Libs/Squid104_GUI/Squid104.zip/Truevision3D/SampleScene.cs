﻿using System;
using System.Collections.Generic;
using System.Text;
using Squid;
using Framework;
using SampleControls;

namespace SquidTV3D
{
    public class SampleScene : DrawableGameComponent
    {
        private Desktop Desktop;

        public SampleScene(Game game)
            : base(game)
        {
        }

        public override void Load()
        {
            Game.Engine.SetVSync(false);
            Game.Engine.EnableProfiler(true);
            Game.Engine.ShowWinCursor(false);
            Game.Engine.DisplayFPS(true);

            Desktop =  new SampleDesktop { Name = "desk" };
            //Desktop = new GameGui();
            Desktop.ShowCursor = true;

            // -- Uncomment to create the texture atlas
            CreateAtlas("SampleMap", 6);

            // -- Uncomment to load and apply the texture atlas
            ReadAtlas("SampleMap");

            base.Load();
        }

        public override void Draw(GameTime time)
        {
            Desktop.Size = new Squid.Point(Game.Engine.GetViewport().GetWidth(), Game.Engine.GetViewport().GetHeight());
            Desktop.Update();
            Desktop.Draw();
        }

        /// <summary>
        /// This method scans all registered styles,
        /// grabs their textures and merges them into a single output texture.
        /// It also adjusts the UV coordinates of the styles accordingly.
        /// The result is an XML file that maps style.Texture to a section of the newly created output texture.
        /// </summary>
        /// <param name="mapName"></param>
        /// <param name="spacing"></param>
        private void CreateAtlas(string mapName, int spacing)
        {
            Atlas atlas = new Atlas();
            int textureSize = 512;
            int dest = Game.Textures.CreateTexture(textureSize, textureSize);
            Squid.RectanglePacker packer = new Squid.RectanglePacker(textureSize, textureSize);
            Dictionary<string, bool> textures = new Dictionary<string, bool>();

            Game.Textures.LockTexture(dest);

            foreach (ControlStyle style in GuiHost.GetSkin().Styles.Values)
            {
                foreach (Style state in style.Styles.Values)
                {
                    if (string.IsNullOrEmpty(state.Texture))
                        continue;

                    string[] filepath = System.IO.Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, state.Texture, System.IO.SearchOption.AllDirectories);
                    if (filepath.Length < 1)
                        continue;

                    if (atlas.Contains(state.Texture))
                        continue;

                    string name = System.IO.Path.GetFileName(filepath[0]);
                    int source = GuiHost.Renderer.GetTexture(name);

                    MTV3D65.TV_TEXTURE info = Game.Textures.GetTextureInfo(source);
                    Squid.Point p = packer.Pack(info.Width + spacing, info.Height + spacing);

                    Game.Textures.LockTexture(source, true);

                    int[] pixels = new int[info.Width * info.Height];
                    Game.Textures.GetPixelArray(source, 0, 0, info.Width, info.Height, pixels);
                    Game.Textures.SetPixelArray(dest, p.x, p.y, info.Width, info.Height, pixels);

                    Game.Textures.UnlockTexture(source);

                    Rectangle rect = new Rectangle();
                    rect.Left = p.x;
                    rect.Top= p.y;
                    rect.Right = p.x + info.Width;
                    rect.Bottom = p.y + info.Height;

                    atlas.Add(state.Texture, rect);
                }
            }

            Game.Textures.UnlockTexture(dest);

            string stub = AppDomain.CurrentDomain.BaseDirectory + "Content\\" + mapName;
            Game.Textures.SaveTexture(dest, stub + ".png", MTV3D65.CONST_TV_IMAGEFORMAT.TV_IMAGE_PNG);
            atlas.Save(stub + ".xml");
        }

        private void ReadAtlas(string mapName)
        {
            Atlas atlas = new Atlas();
            atlas.LoadFile(AppDomain.CurrentDomain.BaseDirectory + "Content\\" + mapName + ".xml");

            foreach (ControlStyle style in GuiHost.GetSkin().Styles.Values)
            {
                foreach (Style state in style.Styles.Values)
                {
                    if (string.IsNullOrEmpty(state.Texture))
                        continue;

                    if (atlas.Contains(state.Texture))
                    {
                        state.TextureRect = atlas.GetRect(state.Texture);
                        state.Texture = mapName + ".png";
                    }
                }
            }
        }
    }
}
