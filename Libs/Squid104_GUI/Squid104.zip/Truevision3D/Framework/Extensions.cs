﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Framework
{
    public static class Extensions
    {
        public static bool IsPowerOfTwo(this int n)
        {
            return ((n != 0) && (n & (n - 1)) == 0);
        }
    }
}
