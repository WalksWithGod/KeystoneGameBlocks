﻿using System;
using System.Collections.Generic;
using System.Text;
using Squid;
using Framework;
using MTV3D65;
using System.Runtime.InteropServices;

namespace SquidTV3D
{
    public class RendererTV3D : ISquidRenderer
    {
        [DllImport("user32.dll")]
        private static extern int GetKeyboardLayout(int dwLayout);
        [DllImport("user32.dll")]
        private static extern int GetKeyboardState(ref byte pbKeyState);
        [DllImport("user32.dll", EntryPoint = "MapVirtualKeyEx")]
        private static extern int MapVirtualKeyExA(int uCode, int uMapType, int dwhkl);
        [DllImport("user32.dll")]
        private static extern int ToAsciiEx(int uVirtKey, int uScanCode, ref byte lpKeyState, ref short lpChar, int uFlags, int dwhkl);

        private Dictionary<string, int> Fonts = new Dictionary<string, int>();
        private Dictionary<string, int> Textures = new Dictionary<string, int>();
        private Dictionary<string, Font> FontTypes = new Dictionary<string, Font>();
        private Dictionary<int, Point> TextureSize = new Dictionary<int, Point>();
        private Dictionary<int, TV_2DVECTOR> InverseTexSize = new Dictionary<int, TV_2DVECTOR>();

        private int KeyboardLayout;
        private byte[] KeyStates;
        private TVViewport Viewport;

        public RendererTV3D()
        {
            FontTypes.Add(Font.Default, new Font { Name = Font.Default, Family = "Arial", Size = 8, Bold = true, International = true });
            FontTypes.Add("arial10", new Font { Name = "arial10", Family = "Arial", Size = 10, Bold = true, International = true });
            KeyboardLayout = GetKeyboardLayout(0);
            KeyStates = new byte[0x100];
        }

        public bool TranslateKey(int code, ref char character)
        {
            short lpChar = 0;
            if (GetKeyboardState(ref KeyStates[0]) == 0)
                return false;

            int result = ToAsciiEx(MapVirtualKeyExA(code, 1, KeyboardLayout), code, ref KeyStates[0], ref lpChar, 0, KeyboardLayout);
            if (result == 1)
            {
                character = (char)((ushort)lpChar);
                return true;
            }

            return false;
        }

        public int GetTexture(string name)
        {
            if (Textures.ContainsKey(name))
                return Textures[name];
            
            int texture = Game.Textures.LoadTexture(name, name, -1, -1, MTV3D65.CONST_TV_COLORKEY.TV_COLORKEY_USE_ALPHA_CHANNEL, false);

            // if texture is not 2^n
            // delete and reload with correct size to avoid stretching
            TV_TEXTURE info = Game.Textures.GetTextureInfo(texture);
            if (!info.RealWidth.IsPowerOfTwo() || !info.RealHeight.IsPowerOfTwo())
            {
                Game.Textures.DeleteTexture(texture);
                texture = Game.Textures.LoadTexture(name, name, info.RealWidth, info.RealHeight, MTV3D65.CONST_TV_COLORKEY.TV_COLORKEY_USE_ALPHA_CHANNEL, false);
            }

            if (texture > 0)
                Textures.Add(name, texture);

            return texture;
        }

        public int GetFont(string name)
        {
            if (Fonts.ContainsKey(name))
                return Fonts[name];

            if (FontTypes.ContainsKey(name))
            {
                Font font = FontTypes[name];
                int index = Game.Text2D.TextureFont_Create(font.Name, font.Family, font.Size, font.Bold, font.Underlined, font.Italic, font.International, true);
                Fonts.Add(name, index);
                return index;
            }

            return -1;
        }

        public Squid.Point GetTextSize(string text, int font)
        {
            if (font < 0) return Point.Zero;

            float x = 0;
            float y = 0;

            Game.Text2D.TextureFont_GetTextSize(text, font, ref x, ref y);
            return new Point { x = (int)x, y = (int)y };
        }

        public Squid.Point GetTextureSize(int texture)
        {
            if (texture < 0) return Point.Zero;

            if (!TextureSize.ContainsKey(texture))
            {
                TV_TEXTURE info = Game.Textures.GetTextureInfo(texture);
                TextureSize.Add(texture, new Point(info.RealWidth, info.RealHeight));
                InverseTexSize.Add(texture, new TV_2DVECTOR(1f / info.RealWidth, 1f / info.RealHeight));
            }

            return TextureSize[texture];
        }

        public TV_2DVECTOR GetInverseTextureSize(int texture)
        {
            if (texture < 0) return new TV_2DVECTOR(0, 0);

            if (!InverseTexSize.ContainsKey(texture))
            {
                TV_TEXTURE info = Game.Textures.GetTextureInfo(texture);
                TextureSize.Add(texture, new Point(info.RealWidth, info.RealHeight));
                InverseTexSize.Add(texture, new TV_2DVECTOR(1f / info.RealWidth, 1f / info.RealHeight));
            }

            return InverseTexSize[texture];
        }

        public void DrawBox(int x, int y, int width, int height, int color)
        {
            Game.Screen2D.Draw_FilledBox(x, y, x + width - 1, y + height - 1, color);
        }

        public void DrawText(string text, int x, int y, int font, int color)
        {
            Game.Text2D.TextureFont_DrawText(text, x, y, color, font);
        }

        public void DrawTexture(int texture, int x, int y, int width, int height, Rectangle source, int color)
        {
            if (texture < 0) return;

            TV_2DVECTOR invSize = GetInverseTextureSize(texture);
            Game.Screen2D.Draw_Texture(texture, x, y, x + width - 1, y + height - 1, color, color, color, color, source.Left * invSize.x, source.Top * invSize.y, source.Right * invSize.x, source.Bottom * invSize.y);
        }

        public void Scissor(int x, int y, int width, int height)
        {
            if (Viewport == null)
                Viewport = Game.Engine.GetViewport();
           
            Viewport.SetTargetArea(x, y, width, height);
        }

        public void StartBatch()
        {
            Game.Text2D.Action_BeginText(true);
        }

        public void EndBatch(bool final)
        {
            Game.Text2D.Action_EndText();
        }

        public void Dispose() { }
    }
}
