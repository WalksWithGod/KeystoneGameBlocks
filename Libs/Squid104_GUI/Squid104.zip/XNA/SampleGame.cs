using System;
using Microsoft.Xna.Framework;
using Squid;

namespace SquidXNA
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class SampleGame : Microsoft.Xna.Framework.Game
    {
        public GraphicsDeviceManager Graphics;
        private FpsCounter FpsCounter;

        public SampleGame()
        {
            this.IsFixedTimeStep = false;
            //this.TargetElapsedTime = TimeSpan.FromSeconds(1d / 8d);

            Graphics = new GraphicsDeviceManager(this);
            Graphics.PreferredBackBufferHeight = 1050;
            Graphics.PreferredBackBufferWidth = 1600;
            Graphics.SynchronizeWithVerticalRetrace = false;
            Graphics.ApplyChanges();
           
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            GuiHost.Renderer = new RendererXNA(this);

            InputManager input = new InputManager(this);
            Components.Add(input);

            SampleScene scene = new SampleScene(this);
            Components.Add(scene);

            FpsCounter = new FpsCounter(this);
            Components.Add(FpsCounter);

            base.Initialize();
        }

        protected override void Draw(GameTime gameTime)
        {
            GuiHost.TimeElapsed = (float)gameTime.ElapsedGameTime.TotalMilliseconds;

            GraphicsDevice.Clear(Microsoft.Xna.Framework.Color.Black);

            base.Draw(gameTime);

            this.Window.Title = FpsCounter.FPS.ToString();
        }
    }
}
