﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
using Framework;

namespace SquidSlimDX
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            using (SampleGame game = new SampleGame())
            {
                game.Form.Size = new System.Drawing.Size(1600, 1080);
                game.Form.StartPosition = FormStartPosition.CenterScreen;
                game.Run();
            }
        }
    }
}
