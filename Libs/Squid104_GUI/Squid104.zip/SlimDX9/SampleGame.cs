﻿using System;
using Framework;
using Squid;

namespace SquidSlimDX
{
    public class SampleGame : Game
    {
        protected override void Initialize()
        {
            GuiHost.Renderer = new RendererSlimDX(Device);

            InputManager input = new InputManager(this);
            Components.Add(input);

            SampleScene scene = new SampleScene(this);
            Components.Add(scene);

            base.Initialize();
        }

        protected override void DeviceReset()
        {
            GuiHost.Renderer.Dispose();
            GuiHost.Renderer = new RendererSlimDX(Device);

            base.DeviceReset();
        }
    }
}
