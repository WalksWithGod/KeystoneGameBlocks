#pragma once

namespace VorbisDotNet
{
	public __value enum VorbisCaps
	{
		None = 0x00,
		GlobalFocus = 0x01,
		ControlVolume = 0x02,
		ControlPan = 0x04,
		ControlEffects = 0x08,
		ControlFrequency = 0x10
	};

	public __gc class VorbisBuffer;
	public __gc class VorbisStreamManager;
	public __gc class VorbisComments;
	public __gc class StoppedEventArgs;

	public __delegate void StoppedEventHandler(System::Object __gc * sender, StoppedEventArgs __gc * e);

	public __gc class StoppedEventArgs : public System::EventArgs
	{
	public:
		StoppedEventArgs(bool a)
		{
			automatic = a;
		}

		__property bool get_Automatic()
		{
			return automatic;
		}
	private:
		bool automatic;
	};

	public __gc class VorbisBuffer : public System::IDisposable
	{
	public:
		VorbisBuffer(System::String __gc * filename, Microsoft::DirectX::DirectSound::Device __gc * device, bool streaming, VorbisCaps caps);
		VorbisBuffer(System::String __gc * filename, Microsoft::DirectX::DirectSound::Device __gc * device, bool streaming, VorbisCaps caps, System::Guid guid3dalg);
		~VorbisBuffer();

		Microsoft::DirectX::DirectSound::Buffer3D __gc * GetBuffer3D();
		__event StoppedEventHandler __gc * Stopped;
		System::Object __gc * GetEffects(int index);
		System::Object __gc * GetEffects(int startIndex, int count)[];
		System::Object __gc * GetObjectInPath(System::Guid obj, int index, System::Guid intf);
		Microsoft::DirectX::DirectSound::EffectsReturnValue SetEffects(Microsoft::DirectX::DirectSound::EffectDescription effs __gc[])[];
		__property int get_Pan();
		__property void set_Pan(int newpan);
		__property int get_Volume();
		__property void set_Volume(int newvol);
		__property int get_Frequency();
		__property void set_Frequency(int newfreq);
		__property System::Collections::Hashtable __gc* get_Comments();
		__property int get_Channels();
		__property Microsoft::DirectX::DirectSound::SecondaryBuffer __gc * get_InternalBuffer();
		virtual void Dispose();
		__property bool get_Streaming();
		__property bool get_Playing();
		__property bool get_Looping();
		__property double get_Position();
		__property void set_Position(double newpos);
		__property double get_Length();
		void Play(bool Loop);
		void Stop();
		void ToStart();
		void UpdateBuffer();
		__property bool get_ManagedStream();
		__property void set_ManagedStream(bool isManaged);
	private:
		void Dispose(bool disposing);
		void BuildComments();

		Microsoft::DirectX::DirectSound::SecondaryBuffer __gc * Buff;
		System::Collections::Hashtable __gc * VorbisComments;
		OggVorbis_File* File;
		unsigned char ManagedBuffer __gc[];
		int BuffLen;
		int AlmostDone;
		int BufferPosition;
		bool IsLooping;
		bool IsPlaying;
		bool Disposed;
		bool Managed;
	};

	public __gc class VorbisStreamManager
	{
	public:
		static void Initialize(bool autoadd);
		static void Terminate();
		static void AddStream(VorbisBuffer __gc * Buffer);
		static void RemoveStream(VorbisBuffer __gc * Buffer);
		__property static bool get_AutoAddNewStreams();
	private:
		static void ThreadProc();
		VorbisStreamManager();

		static System::Threading::AutoResetEvent __gc * QuitEvent;
		static System::Collections::ArrayList __gc * Buffers;
		static System::Threading::Thread __gc * ManagerThread;
		static bool AutoAdd;
	};
};
