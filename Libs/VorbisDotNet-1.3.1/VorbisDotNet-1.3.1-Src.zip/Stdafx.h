// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#define WIN32_LEAN_AND_MEAN

#include <vorbis/vorbisfile.h>
#include <windows.h>
#include <cstdio>

#pragma comment(lib, "ogg_static.lib")
#pragma comment(lib, "vorbis_static.lib")
#pragma comment(lib, "vorbisfile_static.lib")
#ifdef _DEBUG
#pragma comment(lib, "msvcrtd.lib")
#else // #ifdef _DEBUG
#pragma comment(lib, "msvcrt.lib")
#endif
#pragma comment(linker, "/nodefaultlib:libc.lib")
