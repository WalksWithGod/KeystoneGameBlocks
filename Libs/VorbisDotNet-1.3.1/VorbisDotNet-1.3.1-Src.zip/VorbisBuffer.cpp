#include "stdafx.h"
#include "VorbisDotNet.h"

using namespace System;
using namespace System::Collections;
using namespace System::IO;
using namespace System::Diagnostics;
using namespace System::Runtime::InteropServices;
using namespace System::Threading;
using namespace Microsoft::DirectX;
using namespace Microsoft::DirectX::DirectSound;
using namespace VorbisDotNet;


VorbisBuffer::VorbisBuffer(String __gc * filename, Device __gc * device, bool streaming, VorbisCaps caps)
{
	LPCSTR fn = (LPCSTR)Marshal::StringToHGlobalAnsi(filename).ToPointer();
	FILE* fp = fopen(fn, "rb");
	Marshal::FreeHGlobal((void*)fn);
	if(fp == NULL)
		throw new IOException("Could not open file");
	File = new OggVorbis_File;
	if(ov_open(fp, File, NULL, 0) < 0)
	{
		delete File;
		fclose(fp);
		throw new IOException("Could not load Vorbis data");
	}

	BuildComments();

	vorbis_info* vi = ov_info(File, -1);

	WaveFormat wf;
	wf.BitsPerSample = 16;
	wf.Channels = vi->channels;
	wf.BlockAlign = 2 * vi->channels;
	wf.SamplesPerSecond = vi->rate;
	wf.AverageBytesPerSecond = wf.SamplesPerSecond * wf.BlockAlign;
	wf.FormatTag = WaveFormatTag::Pcm;
	BufferDescription* bd = new BufferDescription(wf);
	if(streaming)
	{
		bd->BufferBytes = bd->Format.AverageBytesPerSecond;
		bd->ControlPositionNotify = true;
	}
	else
	{
		bd->BufferBytes = (int)ov_pcm_total(File, -1) * wf.BlockAlign;
		bd->StaticBuffer = true;
	}
	bd->CanGetCurrentPosition = true;
	bd->GlobalFocus = (caps & VorbisCaps::GlobalFocus) ? true : false;
	bd->ControlPan = (caps & VorbisCaps::ControlPan) ? true : false;
	bd->ControlVolume = (caps & VorbisCaps::ControlVolume) ? true : false;
	bd->ControlFrequency = (caps & VorbisCaps::ControlFrequency) ? true : false;
	bd->ControlEffects = (caps & VorbisCaps::ControlEffects) ? true : false;
	BuffLen = bd->BufferBytes;
	Buff = new SecondaryBuffer(bd, device);

	BufferPosition = 0;
	ManagedBuffer = new unsigned char __gc[BuffLen];
	UpdateBuffer();
	delete[] ManagedBuffer;
	ManagedBuffer = NULL;

	if(!streaming)
	{
		ov_clear(File);
		delete File;
		File = NULL;
	}
	else
	{
		ManagedBuffer = new unsigned char __gc[BuffLen / 2];
		if(VorbisStreamManager::AutoAddNewStreams)
			VorbisStreamManager::AddStream(this);
	}
}

VorbisBuffer::VorbisBuffer(String __gc * filename, Device __gc * device, bool streaming, VorbisCaps caps, Guid guid3dalg)
{
	if(caps & VorbisCaps::ControlPan)
		throw new ArgumentException("Cannot control panning on 3D sound");

	LPCSTR fn = (LPCSTR)Marshal::StringToHGlobalAnsi(filename).ToPointer();
	FILE* fp = fopen(fn, "rb");
	Marshal::FreeHGlobal((void*)fn);
	if(fp == NULL)
		throw new IOException("Could not open file");
	File = new OggVorbis_File;
	if(ov_open(fp, File, NULL, 0) < 0)
	{
		delete File;
		fclose(fp);
		throw new IOException("Could not load Vorbis data");
	}

	BuildComments();

	vorbis_info* vi = ov_info(File, -1);
	if(vi->channels > 1)
	{
		ov_clear(File);
		delete File;
		throw new FormatException("You must use mono sound files in 3D buffers");
	}

	WaveFormat wf;
	wf.BitsPerSample = 16;
	wf.Channels = 1;
	wf.BlockAlign = 2;
	wf.SamplesPerSecond = vi->rate;
	wf.AverageBytesPerSecond = wf.SamplesPerSecond * 2;
	wf.FormatTag = WaveFormatTag::Pcm;
	BufferDescription* bd = new BufferDescription(wf);
	if(streaming)
	{
		bd->BufferBytes = bd->Format.AverageBytesPerSecond;
		bd->ControlPositionNotify = true;
	}
	else
	{
		bd->BufferBytes = (int)ov_pcm_total(File, -1) * 2;
		bd->StaticBuffer = true;
	}
	bd->CanGetCurrentPosition = true;
	bd->GlobalFocus = (caps & VorbisCaps::GlobalFocus) ? true : false;
	bd->ControlVolume = (caps & VorbisCaps::ControlVolume) ? true : false;
	bd->ControlEffects = (caps & VorbisCaps::ControlEffects) ? true : false;
	bd->ControlFrequency = (caps & VorbisCaps::ControlFrequency) ? true : false;
	bd->Control3D = true;
	bd->Guid3DAlgorithm = guid3dalg;
	BuffLen = bd->BufferBytes;
	Buff = new SecondaryBuffer(bd, device);

	BufferPosition = 0;
	ManagedBuffer = new unsigned char __gc[BuffLen];
	UpdateBuffer();
	delete[] ManagedBuffer;
	ManagedBuffer = NULL;

	if(!streaming)
	{
		ov_clear(File);
		delete File;
		File = NULL;
	}
	else
	{
		ManagedBuffer = new unsigned char __gc[BuffLen / 2];
		if(VorbisStreamManager::AutoAddNewStreams)
			VorbisStreamManager::AddStream(this);
	}
}

VorbisBuffer::~VorbisBuffer()
{
	Dispose(false);
}

Buffer3D __gc * VorbisBuffer::GetBuffer3D()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return new Buffer3D(Buff);
}

Object __gc * VorbisBuffer::GetEffects(int index)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->GetEffects(index);
}

Object __gc * VorbisBuffer::GetEffects(int startIndex, int count)[]
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->GetEffects(startIndex, count);
}

Object __gc * VorbisBuffer::GetObjectInPath(Guid obj, int index, Guid intf)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->GetObjectInPath(obj, index, intf);
}

EffectsReturnValue VorbisBuffer::SetEffects(EffectDescription effs __gc[])[]
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->SetEffects(effs);
}

Hashtable __gc * VorbisBuffer::get_Comments()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return VorbisComments;
}

double VorbisBuffer::get_Position()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Streaming ? ov_time_tell(File) - ((double)BuffLen / Buff->Format.AverageBytesPerSecond) : (double)Buff->PlayPosition / Buff->Format.AverageBytesPerSecond;
}

void VorbisBuffer::set_Position(double newpos)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");

	Monitor::Enter(this);

	Buff->Stop();
	if(Streaming)
	{
		ov_time_seek(File, newpos);
		BufferPosition = 0;
		AlmostDone = 0;
		delete[] ManagedBuffer;
		ManagedBuffer = new unsigned char __gc [BuffLen];
		Buff->SetCurrentPosition(0);
		UpdateBuffer();
		delete[] ManagedBuffer;
		ManagedBuffer = new unsigned char __gc [BuffLen / 2];
	}
	else
	{
		Buff->SetCurrentPosition((int)(newpos * Buff->Format.AverageBytesPerSecond));
	}
	if(IsPlaying)
		Buff->Play(0, (Streaming || IsLooping) ? BufferPlayFlags::Looping : BufferPlayFlags::Default);

	Monitor::Exit(this);
}

int VorbisBuffer::get_Pan()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->Pan;
}

void VorbisBuffer::set_Pan(int newpan)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	Buff->Pan = newpan;
}

int VorbisBuffer::get_Volume()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->Volume;
}

void VorbisBuffer::set_Volume(int newvol)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	Buff->Volume = newvol;
}

int VorbisBuffer::get_Frequency()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->Format.SamplesPerSecond;
}

void VorbisBuffer::set_Frequency(int newfreq)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	Buff->Frequency = newfreq;
}

SecondaryBuffer __gc * VorbisBuffer::get_InternalBuffer()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff;
}

int VorbisBuffer::get_Channels()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Buff->Format.Channels;
}

double VorbisBuffer::get_Length()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Streaming ? ov_time_total(File, -1) : (double)BuffLen / Buff->Format.AverageBytesPerSecond;
}

void VorbisBuffer::Dispose()
{
	Dispose(true);
	GC::SuppressFinalize(this);
}

bool VorbisBuffer::get_Streaming()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return File != NULL;
}

bool VorbisBuffer::get_Playing()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return IsPlaying;
}

bool VorbisBuffer::get_Looping()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return IsLooping;
}

void VorbisBuffer::Play(bool Loop)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	if(Streaming)
		Buff->Play(0, BufferPlayFlags::Looping);
	else
		Buff->Play(0, Loop ? BufferPlayFlags::Looping : BufferPlayFlags::Default);
	IsPlaying = true;
	IsLooping = Loop;
}

void VorbisBuffer::Stop()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	if(!IsPlaying)
		return;
	Buff->Stop();
	IsPlaying = false;
	Stopped(this, new StoppedEventArgs(false));
}

void VorbisBuffer::ToStart()
{
	Position = 0;
}

void VorbisBuffer::UpdateBuffer()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	if((!Streaming && BufferPosition != 0) || (Buff->PlayPosition >= BuffLen / 2 && BufferPosition == 2) || (Buff->PlayPosition < BuffLen / 2 && BufferPosition == 1))
		return;

	Monitor::Enter(this);
	int pos = 0;
	int s = 0;
	int inc;
	unsigned char __pin * UnmanagedBuffer = &ManagedBuffer[0];
	while(pos < ManagedBuffer->Length)
	{
		inc = ov_read(File, (char*)UnmanagedBuffer + pos, ManagedBuffer->Length - pos, 0, 2, 1, &s);
		pos += inc;
		if(inc == 0)
		{
			if(Looping)
				ov_raw_seek(File, 0);
			else
			{
				if(++AlmostDone == 2)
				{
					Buff->Stop();
					IsPlaying = false;
					ToStart();
					Monitor::Exit(this);
					Stopped(this, new StoppedEventArgs(true));
					return;
				}
				else
				{
					ZeroMemory(UnmanagedBuffer + pos, ManagedBuffer->Length - pos);
					pos = ManagedBuffer->Length;
				}
			}
		}
	}
	if(BufferPosition == 0)
	{
		Buff->Write(0, ManagedBuffer, LockFlag::EntireBuffer);
		BufferPosition = 1;
	}
	else
	{
		if(BufferPosition == 1)
		{
			Buff->Write(0, ManagedBuffer, LockFlag::None);
			BufferPosition = 2;
		}
		else
		{
			Buff->Write(BuffLen / 2, ManagedBuffer, LockFlag::None);
			BufferPosition = 1;
		}
	}
	Monitor::Exit(this);
}

void VorbisBuffer::Dispose(bool disposing)
{
	if(!Disposed)
	{
		if(Managed)
			VorbisStreamManager::RemoveStream(this);
		Monitor::Enter(this);
		if(disposing)
		{
			Buff->Dispose();
			delete[] ManagedBuffer;
			VorbisComments = NULL;
		}
		if(File)
		{
			ov_clear(File);
			delete File;
		}
		Disposed = true;
		Monitor::Exit(this);
	}
}

void VorbisBuffer::BuildComments()
{
	VorbisComments = new Hashtable();

	vorbis_comment* vc = ov_comment(File, -1);

	if(vc)
	{
		for(int i = 0; i < vc->comments; ++i)
		{
			char name[256];
			char* namepos = name;
			char value[256];
			char* valpos = value;
			char* pos = vc->user_comments[i];
			while(*pos != '=')
				*namepos++ = *pos++;
			*namepos = 0;
			++pos;
			while(*pos)
				*valpos++ = *pos++;
			*valpos = 0;
			VorbisComments->Add(new String(name), new String(value));
		}
	}
}

bool VorbisBuffer::get_ManagedStream()
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	return Managed;
}

void VorbisBuffer::set_ManagedStream(bool isManaged)
{
	if(Disposed)
		throw new ObjectDisposedException("Object has been disposed");
	Managed = isManaged;
}
