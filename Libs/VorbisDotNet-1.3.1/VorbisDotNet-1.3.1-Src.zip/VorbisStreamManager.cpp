#include "stdafx.h"
#include "VorbisDotNet.h"

using namespace System;
using namespace System::Collections;
using namespace System::Threading;
using namespace VorbisDotNet;

void VorbisStreamManager::Initialize(bool autoadd)
{
	AutoAdd = autoadd;

	if(Buffers)
		return; // structures are already initialized

	QuitEvent = new AutoResetEvent(false);
	Buffers = new ArrayList();
	ManagerThread = new Thread(new ThreadStart(NULL, &ThreadProc));
	ManagerThread->Name = "Vorbis .NET Stream Manager";
	ManagerThread->Priority = ThreadPriority::Highest;
	ManagerThread->Start();
}

void VorbisStreamManager::Terminate()
{
	if(Buffers == NULL)
		throw new InvalidOperationException("Stream manager not initialized");

	Monitor::Enter(Buffers);
	AutoAdd = false;
	QuitEvent->Set();
	ManagerThread->Join();
	ManagerThread = NULL;
	IEnumerator* i = Buffers->GetEnumerator();
	while(i->MoveNext())
	{
		static_cast<VorbisBuffer*>(static_cast<WeakReference*>(i->Current)->Target)->ManagedStream = false;
	}
	ArrayList __gc * b = Buffers;
	Buffers = NULL;
	Monitor::Exit(b);
}

void VorbisStreamManager::AddStream(VorbisBuffer __gc * Buffer)
{
	if(Buffers == NULL)
		throw new InvalidOperationException("Stream manager not initialized");

	Monitor::Enter(Buffers);
	Buffers->Add(new WeakReference(Buffer));
	Buffer->ManagedStream = true;
	Monitor::Exit(Buffers);
}

void VorbisStreamManager::RemoveStream(VorbisBuffer __gc * Buffer)
{
	if(Buffers == NULL)
		throw new InvalidOperationException("Stream manager not initialized");

	Monitor::Enter(Buffers);
	for(int i = 0; i < Buffers->Count; ++i)
	{
		if(static_cast<WeakReference*>(Buffers->Item[i])->Target == Buffer)
		{
			Buffers->RemoveAt(i);
			Buffer->ManagedStream = false;
			break;
		}
	}
	Monitor::Exit(Buffers);
}

bool VorbisStreamManager::get_AutoAddNewStreams()
{
	return AutoAdd;
}

void VorbisStreamManager::ThreadProc()
{
	while(QuitEvent->WaitOne(20, false) == false)
	{
		Monitor::Enter(Buffers);
		IEnumerator* i = Buffers->GetEnumerator();
		while(i->MoveNext())
		{
			static_cast<VorbisBuffer*>(static_cast<WeakReference*>(i->Current)->Target)->UpdateBuffer();
		}
		Monitor::Exit(Buffers);
	}
}

VorbisStreamManager::VorbisStreamManager()
{
}
